# Analytics & Dashboards Service

Provides:
- Real-time dashboards (production, market flows, price indices, export readiness)
- Food-security warnings (yield gaps, surpluses, shortages)
- Annual open data report and privacy-preserving datasets

## Endpoints
- `POST /dashboard-query`: Query dashboard
- `GET /open-data`: List open datasets
- `POST /open-data`: Publish dataset

See [`api-gateway/openapi-specs/analytics-open-data.yaml`](../../api-gateway/openapi-specs/analytics-open-data.yaml) for the full API spec.