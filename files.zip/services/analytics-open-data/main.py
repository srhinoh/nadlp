@app.post("/open-data", response_model=OpenDataset, status_code=201)
def publish_dataset(dataset: OpenDataset, user_id: str = Header(...)):
    # Check consent for publishing data
    consent_resp = requests.get(f"http://localhost:8005/policy/{user_id}")
    policy = consent_resp.json() if consent_resp.status_code == 200 else {}
    if not policy.get("roles") or "data_publisher" not in policy.get("roles"):
        raise HTTPException(status_code=403, detail="User lacks publishing rights")
    open_datasets_db[dataset.id] = dataset
    return dataset