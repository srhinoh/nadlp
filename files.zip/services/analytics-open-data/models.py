from pydantic import BaseModel
from typing import Dict, Optional

class DashboardQuery(BaseModel):
    dashboard_type: str  # production, market, price, export, food-security
    filters: Optional[Dict[str, str]] = None

class DashboardResult(BaseModel):
    query: DashboardQuery
    result: Dict[str, str]
    timestamp: str

class OpenDataset(BaseModel):
    id: str
    name: str
    description: str
    url: str
    privacy_preserving: bool
    published_at: str