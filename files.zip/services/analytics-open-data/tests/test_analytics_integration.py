import pytest
from fastapi.testclient import TestClient
from services.analytics-open-data.main import app

client = TestClient(app)

def test_dashboard_access_with_policy(monkeypatch):
    def mock_policy_get(url):
        class MockResp:
            def __init__(self): self.status_code = 200
            def json(self): return {"roles": ["analyst", "data_publisher"]}
        return MockResp()
    monkeypatch.setattr("requests.get", mock_policy_get)
    payload = {
        "dashboard_type": "price",
        "filters": {"county": "Bomet"}
    }
    res = client.post("/dashboard-query", json=payload, headers={"user_id": "user001"})
    assert res.status_code == 200
    assert "price_index" in res.json()["result"]

def test_open_data_publish_requires_policy(monkeypatch):
    def mock_policy_get(url):
        class MockResp:
            def __init__(self): self.status_code = 200
            def json(self): return {"roles": ["analyst"]}
        return MockResp()
    monkeypatch.setattr("requests.get", mock_policy_get)
    dataset = {
        "id": "ds001",
        "name": "Annual Maize Production",
        "description": "County-wise maize stats",
        "url": "https://nadlp.ke/open-data/maize",
        "privacy_preserving": True,
        "published_at": "2025-08-26T10:18:00Z"
    }
    res = client.post("/open-data", json=dataset, headers={"user_id": "user001"})
    # Should fail, no 'data_publisher' role
    assert res.status_code == 403