# Extension & Alerts Service

Provides:
- Field inspections (offline/tablet/app)
- Geo-personalized advisories (pest, disease, weather)
- Micro-lessons (Kiswahili/English/local, offline-capable)
- Logistics partner route/pickup alerts

Integrated with Notifications/Comms for message delivery.

## Endpoints
- `POST /inspections`: Field inspection capture
- `GET /inspections/{officer_id}`: Officer inspections
- `POST /advisories`: Advisory push (integrated with Notifications/Comms)
- `GET /advisories/{farmer_id}`: Farmer advisories
- `POST /micro-lessons`: Create micro-lesson
- `GET /micro-lessons/{language}`: Lessons by language
- `POST /logistics-alerts`: Publish logistics route alert (integrated)

## Activation
- Start service: `uvicorn services.extension-alerts.main:app --reload`
- Ensure Notifications/Comms service is running for advisory/logistics alert delivery.
- Run tests: `pytest services/extension-alerts/tests/`

See [`api-gateway/openapi-specs/extension-alerts.yaml`](../../api-gateway/openapi-specs/extension-alerts.yaml) for the full API spec.