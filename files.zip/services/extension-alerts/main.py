from fastapi import FastAPI, HTTPException
from .models import Inspection, Advisory, MicroLesson, LogisticsAlert
import requests

app = FastAPI(
    title="NADLP Extension & Alerts API",
    description="Field inspections, geo-personalized advisories, micro-lessons, and logistics alerts.",
    version="1.0.0"
)

inspections_db = {}
advisories_db = {}
micro_lessons_db = {}
logistics_alerts_db = {}

NOTIFICATIONS_URL = "http://localhost:8004/alerts"  # Example: notifications-comms service

@app.post("/inspections", response_model=Inspection, status_code=201)
def create_inspection(inspection: Inspection):
    inspections_db[inspection.id] = inspection
    return inspection

@app.get("/inspections/{officer_id}", response_model=list[Inspection])
def get_officer_inspections(officer_id: str):
    return [i for i in inspections_db.values() if i.officer_id == officer_id]

@app.post("/advisories", response_model=Advisory, status_code=201)
def push_advisory(advisory: Advisory):
    advisories_db[advisory.id] = advisory
    # Integration: push notification
    try:
        requests.post(NOTIFICATIONS_URL, json={
            "id": advisory.id,
            "user_id": advisory.farmer_id,
            "channel": "sms",
            "message": advisory.message,
            "category": advisory.type,
            "critical": True if advisory.type in ["pest", "disease", "weather"] else False,
            "delivered": False,
            "timestamp": advisory.timestamp
        })
    except Exception as e:
        # Log error but continue flow
        print(f"Failed to push advisory: {e}")
    return advisory

@app.get("/advisories/{farmer_id}", response_model=list[Advisory])
def get_farmer_advisories(farmer_id: str):
    return [a for a in advisories_db.values() if a.farmer_id == farmer_id]

@app.post("/micro-lessons", response_model=MicroLesson, status_code=201)
def create_micro_lesson(lesson: MicroLesson):
    micro_lessons_db[lesson.id] = lesson
    return lesson

@app.get("/micro-lessons/{language}", response_model=list[MicroLesson])
def get_lessons_by_language(language: str):
    return [l for l in micro_lessons_db.values() if l.language == language]

@app.post("/logistics-alerts", response_model=LogisticsAlert, status_code=201)
def publish_logistics_alert(alert: LogisticsAlert):
    logistics_alerts_db[alert.id] = alert
    # Integration: push notification
    try:
        requests.post(NOTIFICATIONS_URL, json={
            "id": alert.id,
            "user_id": alert.partner_id,
            "channel": "sms",
            "message": alert.message,
            "category": "logistics",
            "critical": False,
            "delivered": False,
            "timestamp": alert.timestamp
        })
    except Exception as e:
        print(f"Failed to push logistics alert: {e}")
    return alert