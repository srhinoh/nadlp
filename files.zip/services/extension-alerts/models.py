from pydantic import BaseModel
from typing import Optional, List

class Inspection(BaseModel):
    id: str
    officer_id: str
    farmer_id: str
    time: str
    gps: dict
    photos: List[str]
    form_data: dict
    synced: bool = False

class Advisory(BaseModel):
    id: str
    farmer_id: str
    plot_id: Optional[str]
    type: str  # pest, disease, weather
    message: str
    geojson: Optional[dict]
    language: str  # en, sw, local
    timestamp: str

class MicroLesson(BaseModel):
    id: str
    title: str
    content: str
    language: str  # en, sw, local
    offline_capable: bool = True

class LogisticsAlert(BaseModel):
    id: str
    partner_id: str
    route: str
    pickup_window: str
    message: str
    timestamp: str