import pytest
from fastapi.testclient import TestClient
from services.extension-alerts.main import app

client = TestClient(app)

def test_field_inspection_creation():
    payload = {
        "id": "insp001",
        "officer_id": "officer123",
        "farmer_id": "farmer123",
        "time": "2025-08-26T10:00:00Z",
        "gps": {"lat": -1.25, "lon": 36.8},
        "photos": [],
        "form_data": {"crop": "Maize", "condition": "Good"},
        "synced": False
    }
    res = client.post("/inspections", json=payload)
    assert res.status_code == 201
    assert res.json()["id"] == "insp001"

def test_push_advisory_and_fetch():
    advisory = {
        "id": "adv001",
        "farmer_id": "farmer123",
        "plot_id": "plot001",
        "type": "pest",
        "message": "Fall armyworm detected. Apply recommended pesticide.",
        "geojson": None,
        "language": "en",
        "timestamp": "2025-08-26T10:10:00Z"
    }
    res = client.post("/advisories", json=advisory)
    assert res.status_code == 201
    # Fetch advisories
    res2 = client.get("/advisories/farmer123")
    assert res2.status_code == 200
    assert any(a["id"] == "adv001" for a in res2.json())

def test_micro_lesson_creation_and_language_filter():
    lesson = {
        "id": "lesson001",
        "title": "Soil Testing Basics",
        "content": "How to test soil for nutrients.",
        "language": "en",
        "offline_capable": True
    }
    client.post("/micro-lessons", json=lesson)
    res = client.get("/micro-lessons/en")
    assert res.status_code == 200
    assert any(l["id"] == "lesson001" for l in res.json())

def test_publish_logistics_alert():
    alert = {
        "id": "log001",
        "partner_id": "partnerX",
        "route": "Bomet-Nairobi",
        "pickup_window": "2025-08-27T09:00:00Z-12:00:00Z",
        "message": "Truck will pick up maize at 10am.",
        "timestamp": "2025-08-26T10:12:00Z"
    }
    res = client.post("/logistics-alerts", json=alert)
    assert res.status_code == 201
    # Alerts DB should contain the alert
    # Optional: check notifications-comms integration (mocked)