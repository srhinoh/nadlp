# Farmer Registry & GIS Service

Manages farmer registration, KYC, and geo-mapped plots.  
Provides verified farmer IDs and plot boundaries for market eligibility, extension targeting, and analytics.

## Endpoints
- `POST /farmers`: Register farmer with KYC
- `GET /farmers/{farmer_id}`: Retrieve farmer profile
- `POST /farmers/{farmer_id}/plots`: Add mapped plot to farmer

Integrated with Marketplace for listing eligibility and traceability.