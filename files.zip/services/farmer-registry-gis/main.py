from fastapi import FastAPI, HTTPException
from .models import Farmer, Plot

app = FastAPI(
    title="NADLP Farmer Registry GIS API",
    description="Farmer profiles, KYC, plot mapping, and geo-personalized registry.",
    version="1.0.0"
)

farmers_db = {}

@app.post("/farmers", response_model=Farmer, status_code=201)
def register_farmer(farmer: Farmer):
    if farmer.id in farmers_db:
        raise HTTPException(status_code=409, detail="Farmer already exists")
    farmers_db[farmer.id] = farmer
    return farmer

@app.get("/farmers/{farmer_id}", response_model=Farmer)
def get_farmer(farmer_id: str):
    farmer = farmers_db.get(farmer_id)
    if not farmer:
        raise HTTPException(status_code=404, detail="Farmer not found")
    return farmer

@app.post("/farmers/{farmer_id}/plots", response_model=Plot, status_code=201)
def add_plot(farmer_id: str, plot: Plot):
    farmer = farmers_db.get(farmer_id)
    if not farmer:
        raise HTTPException(status_code=404, detail="Farmer not found")
    farmer.plots.append(plot)
    return plot