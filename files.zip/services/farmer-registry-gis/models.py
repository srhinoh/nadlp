from pydantic import BaseModel
from typing import List, Optional

class Plot(BaseModel):
    id: str
    geojson: dict
    crop_history: List[str]
    irrigation: Optional[str]
    tenure: Optional[str]

class Farmer(BaseModel):
    id: str
    kyc_id: str
    phone: str
    coop: Optional[str]
    gender: str
    age_band: str
    plots: List[Plot] = []