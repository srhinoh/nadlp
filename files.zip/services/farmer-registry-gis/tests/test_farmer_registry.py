import pytest
from fastapi.testclient import TestClient
from services.farmer-registry-gis.main import app

client = TestClient(app)

def test_register_and_get_farmer():
    payload = {
        "id": "farmer001",
        "kyc_id": "ID123456",
        "phone": "0712345678",
        "coop": "SunCoop",
        "gender": "male",
        "age_band": "40-49",
        "plots": []
    }
    res = client.post("/farmers", json=payload)
    assert res.status_code == 201
    # Retrieve farmer
    res2 = client.get("/farmers/farmer001")
    assert res2.status_code == 200
    assert res2.json()["kyc_id"] == "ID123456"

def test_add_plot_to_farmer():
    # Register farmer
    payload = {
        "id": "farmer002",
        "kyc_id": "ID654321",
        "phone": "0723456789",
        "coop": None,
        "gender": "female",
        "age_band": "30-39",
        "plots": []
    }
    res = client.post("/farmers", json=payload)
    assert res.status_code == 201
    # Add plot
    plot_payload = {
        "id": "plot001",
        "geojson": {"type": "Polygon", "coordinates": [[[36.8, -1.2], [36.9, -1.2], [36.9, -1.3], [36.8, -1.3], [36.8, -1.2]]]},
        "crop_history": ["Maize", "Beans"],
        "irrigation": "Drip",
        "tenure": "Owned"
    }
    res2 = client.post("/farmers/farmer002/plots", json=plot_payload)
    assert res2.status_code == 201