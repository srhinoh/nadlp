# Identity & Consent Service

Implements:
- RBAC/ABAC access management
- Explicit consent capture and revocation
- Consent ledger for audit/compliance
- Least privilege policy enforcement

## Endpoints
- `POST /consent`: Grant explicit consent
- `POST /consent/revoke`: Revoke explicit consent
- `POST /policy`: Set user RBAC/ABAC policy
- `GET /policy/{user_id}`: Get user policy

See [`api-gateway/openapi-specs/identity-consent.yaml`](../../api-gateway/openapi-specs/identity-consent.yaml) for the full API spec.