from fastapi import FastAPI, HTTPException
from .models import Consent, ConsentLog, UserPolicy

app = FastAPI(
    title="NADLP Identity & Consent API",
    description="RBAC/ABAC, explicit consent capture/revocation, and consent ledger.",
    version="1.0.0"
)

consent_db = {}
consent_log_db = {}
policies_db = {}

@app.post("/consent", response_model=Consent, status_code=201)
def capture_consent(consent: Consent):
    consent_db[consent.user_id] = consent
    # Log consent event
    consent_log_db[consent.user_id] = ConsentLog(
        user_id=consent.user_id,
        action="grant",
        purpose=consent.purpose,
        timestamp=consent.timestamp
    )
    return consent

@app.post("/consent/revoke", response_model=ConsentLog)
def revoke_consent(user_id: str, purpose: str, timestamp: str):
    # Remove consent and log event
    if user_id in consent_db:
        del consent_db[user_id]
    log = ConsentLog(
        user_id=user_id, action="revoke", purpose=purpose, timestamp=timestamp
    )
    consent_log_db[user_id] = log
    return log

@app.post("/policy", response_model=UserPolicy, status_code=201)
def set_policy(policy: UserPolicy):
    policies_db[policy.user_id] = policy
    return policy

@app.get("/policy/{user_id}", response_model=UserPolicy)
def get_policy(user_id: str):
    policy = policies_db.get(user_id)
    if not policy:
        raise HTTPException(status_code=404, detail="No policy for user")
    return policy