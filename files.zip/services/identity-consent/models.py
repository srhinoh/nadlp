from pydantic import BaseModel
from typing import Optional, List

class Consent(BaseModel):
    user_id: str
    purpose: str  # e.g. data sharing, analytics, notifications
    scope: str
    retention: str
    granted: bool
    timestamp: str

class ConsentLog(BaseModel):
    user_id: str
    action: str  # grant, revoke
    purpose: str
    timestamp: str

class UserPolicy(BaseModel):
    user_id: str
    roles: List[str]
    attributes: Optional[dict]
    least_privilege: bool = True