# Marketplace & Traceability Service

Implements core commodity listing, offer management, and digital contract flows for farmers, buyers, and cooperatives.  
Supports traceability, inspector verification, certification, and compliance for export-grade commodities.  
Integrates with payments/escrow, notifications, and analytics modules.

## Endpoints
- `POST /listings`: Create a new commodity listing
- `GET /listings`: Search/filter listings
- `POST /listings/{listing_id}/offer`: Submit an offer for a listing

See [`api-gateway/openapi-specs/marketplace.yaml`](../../api-gateway/openapi-specs/marketplace.yaml) for full API spec.