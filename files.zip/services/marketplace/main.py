# Add import for HTTP client
import requests

FARMER_REGISTRY_URL = "http://localhost:8001/farmers"

@app.post("/listings", response_model=Listing, status_code=201)
def create_listing(listing: Listing):
    # Validate farmer existence
    farmer_resp = requests.get(f"{FARMER_REGISTRY_URL}/{listing.id}")
    if farmer_resp.status_code != 200:
        raise HTTPException(status_code=400, detail="Farmer not registered")
    listings_db.append(listing)
    return listing