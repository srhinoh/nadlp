from pydantic import BaseModel, Field
from typing import List, Optional

class Listing(BaseModel):
    id: str
    commodity: str
    grade: str
    quantity: float
    location: str
    delivery_terms: Optional[str]
    validity: Optional[str]
    reserve_price: Optional[float]
    certifications: List[str] = []
    inspector_verified: Optional[bool] = False
    traceability_chain: Optional[List[str]] = []

class Offer(BaseModel):
    id: str
    listing_id: str
    buyer_id: str
    price: float
    delivery_window: Optional[str]
    terms: Optional[str]
    status: str = "pending"  # pending, accepted, rejected, countered