# Marketplace & Farmer Registry Integration Tests

These tests validate the connection between Farmer Registry and Marketplace modules:

- **Listing creation** is only possible for registered farmers.
- **Farmer registration and retrieval** work as expected.
- **Plot addition** to farmer profiles is supported.

Run with:
```bash
pytest services/marketplace/tests/
pytest services/farmer-registry-gis/tests/
```