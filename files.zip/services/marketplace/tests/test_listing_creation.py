import pytest
from fastapi.testclient import TestClient

from services.marketplace.main import app as marketplace_app
from services.farmer-registry-gis.main import app as registry_app

marketplace_client = TestClient(marketplace_app)
registry_client = TestClient(registry_app)

def test_listing_creation_only_for_registered_farmer():
    # Register a farmer
    farmer_payload = {
        "id": "farmer123",
        "kyc_id": "ID987654",
        "phone": "0700123456",
        "coop": "GreenFarmers",
        "gender": "female",
        "age_band": "30-39",
        "plots": []
    }
    res = registry_client.post("/farmers", json=farmer_payload)
    assert res.status_code == 201

    # Create a valid listing for the farmer
    listing_payload = {
        "id": "farmer123",  # farmer ID matches
        "commodity": "Maize",
        "grade": "A",
        "quantity": 1000,
        "location": "Bomet",
        "delivery_terms": "FOB",
        "validity": "2025-12-31",
        "reserve_price": 2000,
        "certifications": ["KEPHIS"],
        "inspector_verified": True,
        "traceability_chain": []
    }
    res = marketplace_client.post("/listings", json=listing_payload)
    assert res.status_code == 201

    # Attempt to create listing with unregistered farmer
    listing_payload["id"] = "not_a_farmer"
    res = marketplace_client.post("/listings", json=listing_payload)
    assert res.status_code == 400
    assert "Farmer not registered" in res.text