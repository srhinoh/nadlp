# Notifications & Communications Service

Enables multi-channel messaging for alerts, confirmations, and transactional updates:
- In-app, SMS, USSD, email, IVR
- Critical alerts (pest, weather, payment, logistics) with SMS fallback
- Supports integration with Marketplace, Registry, Payments, Warehousing

## Endpoints
- `POST /notify`: Send notification (multi-channel)
- `POST /alerts`: Send critical alert (SMS fallback)
- `GET /notifications/{user_id}`: Get user notifications
- `GET /alerts/{user_id}`: Get user alerts

See [`api-gateway/openapi-specs/notifications-comms.yaml`](../../api-gateway/openapi-specs/notifications-comms.yaml) for full API spec.