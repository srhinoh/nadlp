from fastapi import FastAPI, HTTPException
from .models import Notification, Alert

app = FastAPI(
    title="NADLP Notifications & Communications API",
    description="Multi-channel messaging: in-app, SMS, USSD, email, IVR for alerts and confirmations.",
    version="1.0.0"
)

notifications_db = {}
alerts_db = {}

@app.post("/notify", response_model=Notification, status_code=201)
def send_notification(notification: Notification):
    notifications_db[notification.id] = notification
    # TODO: Integrate with SMS, USSD, email, IVR providers
    return notification

@app.post("/alerts", response_model=Alert, status_code=201)
def send_alert(alert: Alert):
    alerts_db[alert.id] = alert
    # TODO: Implement SMS fallback for critical alerts
    return alert

@app.get("/notifications/{user_id}", response_model=list[Notification])
def get_user_notifications(user_id: str):
    return [n for n in notifications_db.values() if n.user_id == user_id]

@app.get("/alerts/{user_id}", response_model=list[Alert])
def get_user_alerts(user_id: str):
    return [a for a in alerts_db.values() if a.user_id == user_id]