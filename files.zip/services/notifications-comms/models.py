from pydantic import BaseModel
from typing import Optional, List

class Notification(BaseModel):
    id: str
    user_id: str
    channel: str  # in-app, sms, ussd, email, ivr
    message: str
    type: str  # info, transaction, confirmation
    read: bool = False
    timestamp: Optional[str]

class Alert(BaseModel):
    id: str
    user_id: str
    channel: str  # sms, ussd, ivr, in-app
    message: str
    category: str  # pest, weather, payment, logistics, compliance
    critical: bool = False
    delivered: bool = False
    timestamp: Optional[str]