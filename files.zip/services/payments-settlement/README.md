# Payments & Settlement Service

Handles escrow, payouts, and financial event recording for marketplace contracts.  
Integrates with mobile money and bank APIs, and supports contract-linked settlement flows.

## Endpoints
- `POST /payments`: Initiate payment (escrow, payout, fee)
- `GET /payments/{payment_id}`: Query payment
- `POST /settlements`: Settle contract after delivery verification
- `POST /financial-events`: Record financial event for audit/analytics

See [`api-gateway/openapi-specs/payments-settlement.yaml`](../../api-gateway/openapi-specs/payments-settlement.yaml) for the full API spec.