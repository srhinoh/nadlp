from fastapi import FastAPI, HTTPException
from .models import Payment, Settlement, FinancialEvent

app = FastAPI(
    title="NADLP Payments & Settlement API",
    description="Handles escrow, payouts, and financial event recording for the marketplace.",
    version="1.0.0"
)

payments_db = {}
settlements_db = {}
financial_events_db = {}

@app.post("/payments", response_model=Payment, status_code=201)
def initiate_payment(payment: Payment):
    if payment.id in payments_db:
        raise HTTPException(status_code=409, detail="Payment already exists")
    payments_db[payment.id] = payment
    # TODO: Integrate with mobile money/bank APIs
    return payment

@app.get("/payments/{payment_id}", response_model=Payment)
def get_payment(payment_id: str):
    payment = payments_db.get(payment_id)
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    return payment

@app.post("/settlements", response_model=Settlement, status_code=201)
def settle_contract(settlement: Settlement):
    if settlement.id in settlements_db:
        raise HTTPException(status_code=409, detail="Settlement already exists")
    settlements_db[settlement.id] = settlement
    # TODO: Verify delivery, release funds
    return settlement

@app.post("/financial-events", response_model=FinancialEvent, status_code=201)
def record_financial_event(event: FinancialEvent):
    financial_events_db[event.id] = event
    return event