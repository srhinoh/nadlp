from pydantic import BaseModel
from typing import Optional

class Payment(BaseModel):
    id: str
    contract_id: str
    payer_id: str
    payee_id: str
    amount: float
    method: str  # mobile_money, bank_transfer, escrow
    status: str = "pending"  # pending, completed, failed
    timestamp: Optional[str]

class Settlement(BaseModel):
    id: str
    contract_id: str
    delivery_verified: bool
    amount: float
    released_to: str
    status: str = "pending"  # pending, released, disputed, refunded
    timestamp: Optional[str]

class FinancialEvent(BaseModel):
    id: str
    event_type: str  # payment, settlement, fee, tax, refund
    contract_id: Optional[str]
    amount: float
    details: Optional[str]
    timestamp: Optional[str]